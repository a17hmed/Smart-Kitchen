/*
    Smart Kitchen - TUIO Fiducial Markers System
    Professional Scan-Based Cooking Assistant

    Features:
    - Scan ingredient or physical kitchen object once and keep it saved
    - Use marker rotation to estimate quantity
    - Show calories, health score, meal suggestions, missing items, and cooking steps
    - Support physical kitchen objects: Spoon, Pot, Knife
    - C = Clear all scans
    - R = Remove last scanned marker
    - H = Toggle health tips
    - M = Toggle meal steps

    Marker Mapping:
        0 = Chicken   (Ingredient)
        1 = Tomato    (Ingredient)
        2 = Onion     (Ingredient)
        3 = Spices    (Ingredient)
        4 = Rice      (Ingredient)
        5 = Oil       (Ingredient)
        6 = Spoon     (Physical Object / Tool)
        7 = Pot       (Physical Object / Tool)
        8 = Knife     (Physical Object / Tool)
*/

using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using TUIO;

public class SmartKitchenDemo : Form, TuioListener
{
    public static int width;
    public static int height;

    private TuioClient client;
    private Dictionary<long, TuioDemoObject> objectList = new Dictionary<long, TuioDemoObject>();
    private readonly object objectSync = new object();

    private Dictionary<int, TuioDemoObject> scannedMarkers = new Dictionary<int, TuioDemoObject>();
    private readonly object scannedSync = new object();
    private List<int> scanHistory = new List<int>();

    private bool showHealthTips = true;
    private bool showMealSteps = true;
    private bool isLoggedIn = false;
    private const int LOGIN_MARKER_ID = 25;

    private int WIN_W = 1280;
    private int WIN_H = 760;

    private static Color BG = Color.FromArgb(245, 245, 240);
    private static Color CARD_BG = Color.White;
    private static Color GREEN = Color.FromArgb(29, 158, 117);
    private static Color GREEN_LIGHT = Color.FromArgb(225, 245, 238);
    private static Color AMBER = Color.FromArgb(186, 117, 23);
    private static Color AMBER_LIGHT = Color.FromArgb(250, 238, 218);
    private static Color CORAL = Color.FromArgb(216, 90, 48);
    private static Color CORAL_LIGHT = Color.FromArgb(250, 236, 231);
    private static Color BLUE = Color.FromArgb(52, 120, 246);
    private static Color BLUE_LIGHT = Color.FromArgb(232, 239, 254);
    private static Color PURPLE = Color.FromArgb(121, 84, 181);
    private static Color PURPLE_LIGHT = Color.FromArgb(240, 233, 249);
    private static Color TEAL_DARK = Color.FromArgb(8, 80, 65);
    private static Color GRAY_MID = Color.FromArgb(95, 94, 90);
    private static Color GRAY_LIGHT = Color.FromArgb(241, 239, 232);
    private static Color TEXT_PRI = Color.FromArgb(20, 20, 18);
    private static Color TEXT_SEC = Color.FromArgb(120, 119, 112);

    private Font fontTitle = new Font("Segoe UI", 18, FontStyle.Bold);
    private Font fontH2 = new Font("Segoe UI", 13, FontStyle.Bold);
    private Font fontH3 = new Font("Segoe UI", 11, FontStyle.Bold);
    private Font fontBody = new Font("Segoe UI", 10);
    private Font fontSmall = new Font("Segoe UI", 9);
    private Font fontBig = new Font("Segoe UI", 22, FontStyle.Bold);
    private Font fontMarker = new Font("Segoe UI", 9, FontStyle.Bold);
    private Font fontTiny = new Font("Segoe UI", 8);
    private Font fontEmoji = new Font("Segoe UI Emoji", 20, FontStyle.Regular);

    private enum ItemType
    {
        Ingredient,
        Tool
    }

    private class KitchenItem
    {
        public int MarkerID;
        public string Name;
        public string Emoji;
        public ItemType Type;
        public float KcalPerGram;
        public int GramSmall;
        public int GramMed;
        public int GramLarge;
        public int GramXLarge;
        public string[] Tips;
        public Color AccentColor;
        public Color LightColor;

        public bool IsTool
        {
            get { return Type == ItemType.Tool; }
        }

        public int GetGrams(float angle)
        {
            if (IsTool) return 0;

            float deg = angle * 180f / (float)Math.PI;
            if (deg < 0) deg += 360f;

            if (deg < 90f) return GramSmall;
            if (deg < 180f) return GramMed;
            if (deg < 270f) return GramLarge;
            return GramXLarge;
        }

        public string GetQtyLabel(float angle)
        {
            if (IsTool) return "Tool Ready";

            float deg = angle * 180f / (float)Math.PI;
            if (deg < 0) deg += 360f;

            if (deg < 90f) return "Small";
            if (deg < 180f) return "Medium";
            if (deg < 270f) return "Large";
            return "X-Large";
        }

        public int GetCalories(float angle)
        {
            if (IsTool) return 0;
            return (int)(KcalPerGram * GetGrams(angle));
        }
    }

    private class Recipe
    {
        public string Name;
        public string Emoji;
        public int[] RequiredMarkers;
        public int BaseKcal;
        public string Category;
        public string[] Steps;
    }

    private KitchenItem[] items = new KitchenItem[]
    {
        new KitchenItem {
            MarkerID=0, Name="Chicken", Emoji="🍗", Type=ItemType.Ingredient,
            KcalPerGram=1.65f,
            GramSmall=100, GramMed=200, GramLarge=300, GramXLarge=400,
            AccentColor=CORAL, LightColor=CORAL_LIGHT,
            Tips=new string[]{"Use grilled chicken instead of fried.","Rich in protein and suitable for balanced meals.","Remove skin to reduce calories."}
        },
        new KitchenItem {
            MarkerID=1, Name="Tomato", Emoji="🍅", Type=ItemType.Ingredient,
            KcalPerGram=0.18f,
            GramSmall=80, GramMed=150, GramLarge=250, GramXLarge=350,
            AccentColor=GREEN, LightColor=GREEN_LIGHT,
            Tips=new string[]{"Low calorie and rich in antioxidants.","Adds freshness to healthy dishes.","Good source of vitamins."}
        },
        new KitchenItem {
            MarkerID=2, Name="Onion", Emoji="🧅", Type=ItemType.Ingredient,
            KcalPerGram=0.40f,
            GramSmall=50, GramMed=100, GramLarge=150, GramXLarge=200,
            AccentColor=AMBER, LightColor=AMBER_LIGHT,
            Tips=new string[]{"Enhances flavor without much fat.","Useful in soups and many healthy meals."}
        },
        new KitchenItem {
            MarkerID=3, Name="Spices", Emoji="🌶", Type=ItemType.Ingredient,
            KcalPerGram=0.25f,
            GramSmall=5, GramMed=10, GramLarge=20, GramXLarge=30,
            AccentColor=CORAL, LightColor=CORAL_LIGHT,
            Tips=new string[]{"Improves flavor without heavy sauces.","Use herbs and spices to reduce salt.","Turmeric may support anti-inflammatory diets."}
        },
        new KitchenItem {
            MarkerID=4, Name="Rice", Emoji="🍚", Type=ItemType.Ingredient,
            KcalPerGram=1.30f,
            GramSmall=50, GramMed=100, GramLarge=150, GramXLarge=200,
            AccentColor=GRAY_MID, LightColor=GRAY_LIGHT,
            Tips=new string[]{"Control rice portion size.","Brown rice is a healthier option.","Rice gives good energy but watch quantity."}
        },
        new KitchenItem {
            MarkerID=5, Name="Oil", Emoji="💧", Type=ItemType.Ingredient,
            KcalPerGram=8.84f,
            GramSmall=5, GramMed=10, GramLarge=15, GramXLarge=20,
            AccentColor=AMBER, LightColor=AMBER_LIGHT,
            Tips=new string[]{"Use small amounts of oil.","Oil is high in calories.","Prefer olive oil and avoid excess quantity."}
        },
        new KitchenItem {
            MarkerID=6, Name="Spoon", Emoji="🥄", Type=ItemType.Tool,
            KcalPerGram=0f,
            GramSmall=0, GramMed=0, GramLarge=0, GramXLarge=0,
            AccentColor=BLUE, LightColor=BLUE_LIGHT,
            Tips=new string[]{"A spoon is a physical kitchen object used for mixing and serving."}
        },
        new KitchenItem {
            MarkerID=7, Name="Pot", Emoji="🍲", Type=ItemType.Tool,
            KcalPerGram=0f,
            GramSmall=0, GramMed=0, GramLarge=0, GramXLarge=0,
            AccentColor=PURPLE, LightColor=PURPLE_LIGHT,
            Tips=new string[]{"A pot is a physical cooking object required for soups and cooked meals."}
        },
        new KitchenItem {
            MarkerID=8, Name="Knife", Emoji="🔪", Type=ItemType.Tool,
            KcalPerGram=0f,
            GramSmall=0, GramMed=0, GramLarge=0, GramXLarge=0,
            AccentColor=BLUE, LightColor=BLUE_LIGHT,
            Tips=new string[]{"A knife is a physical kitchen object used for chopping and preparation."}
        }
    };

    private Recipe[] recipes = new Recipe[]
    {
        new Recipe {
            Name="Chicken with Tomato",
            Emoji="🍲",
            RequiredMarkers=new int[]{0,1,3,6,7,8},
            BaseKcal=320,
            Category="High Protein",
            Steps=new string[]{
                "Use the knife to cut chicken and tomato.",
                "Place the pot on the cooking area.",
                "Add chicken to the pot.",
                "Add tomato and spices.",
                "Use the spoon to mix and cook for 15 minutes."
            }
        },
        new Recipe {
            Name="Chicken Soup",
            Emoji="🥣",
            RequiredMarkers=new int[]{0,2,3,6,7,8},
            BaseKcal=280,
            Category="Healthy Soup",
            Steps=new string[]{
                "Use the knife to cut onion and chicken.",
                "Place ingredients in the pot.",
                "Add spices and water.",
                "Use the spoon to stir.",
                "Cook until chicken is ready."
            }
        },
        new Recipe {
            Name="Chicken Rice Bowl",
            Emoji="🍛",
            RequiredMarkers=new int[]{0,4,3,5,6,7,8},
            BaseKcal=520,
            Category="Balanced Meal",
            Steps=new string[]{
                "Use the knife to prepare chicken.",
                "Add a small amount of oil to the pot.",
                "Cook chicken with spices.",
                "Add rice and continue cooking.",
                "Serve using the spoon."
            }
        },
        new Recipe {
            Name="Tomato Rice",
            Emoji="🍅",
            RequiredMarkers=new int[]{1,4,5,6,7,8},
            BaseKcal=350,
            Category="Vegetarian",
            Steps=new string[]{
                "Use the knife to cut tomato.",
                "Heat a small amount of oil in the pot.",
                "Add tomato and rice.",
                "Use the spoon to stir.",
                "Cook until rice is soft."
            }
        },
        new Recipe {
            Name="Healthy Chicken Dish",
            Emoji="🥗",
            RequiredMarkers=new int[]{0,1,2,3,6,7,8},
            BaseKcal=410,
            Category="Healthy Balanced Meal",
            Steps=new string[]{
                "Use the knife to prepare chicken, onion, and tomato.",
                "Place everything in the pot.",
                "Add spices only in moderate quantity.",
                "Use the spoon to stir and cook.",
                "Serve as a healthy meal."
            }
        }
    };

    private const int PAD = 16;
    private const int CARD_R = 12;

    public SmartKitchenDemo(int port)
    {
        width = WIN_W;
        height = WIN_H;

        this.Text = "Smart Kitchen - TUIO Professional Cooking Assistant";
        this.ClientSize = new Size(WIN_W, WIN_H);
        this.BackColor = BG;
        this.FormBorderStyle = FormBorderStyle.FixedSingle;
        this.MaximizeBox = false;
        this.StartPosition = FormStartPosition.CenterScreen;

        this.SetStyle(
            ControlStyles.AllPaintingInWmPaint |
            ControlStyles.UserPaint |
            ControlStyles.DoubleBuffer,
            true
        );

        this.KeyDown += new KeyEventHandler(Form_KeyDown);
        this.Closing += new CancelEventHandler(Form_Closing);

        client = new TuioClient(port);
        client.addTuioListener(this);
        client.connect();
    }

    private void Form_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape)
        {
            this.Close();
        }
        else if (e.KeyCode == Keys.C)
        {
            lock (scannedSync)
            {
                scannedMarkers.Clear();
                scanHistory.Clear();
            }

            Console.WriteLine("[CLEAR] All scanned items removed.");
            Invalidate();
        }
        else if (e.KeyCode == Keys.R)
        {
            RemoveLastScannedItem();
        }
        else if (e.KeyCode == Keys.H)
        {
            showHealthTips = !showHealthTips;
            Invalidate();
        }
        else if (e.KeyCode == Keys.M)
        {
            showMealSteps = !showMealSteps;
            Invalidate();
        }
    }

    private void RemoveLastScannedItem()
    {
        lock (scannedSync)
        {
            if (scanHistory.Count == 0) return;

            int lastMarker = scanHistory[scanHistory.Count - 1];
            scanHistory.RemoveAt(scanHistory.Count - 1);

            if (scannedMarkers.ContainsKey(lastMarker))
                scannedMarkers.Remove(lastMarker);
        }

        Console.WriteLine("[REMOVE] Last scanned marker removed.");
        Invalidate();
    }

    private void Form_Closing(object sender, CancelEventArgs e)
    {
        client.removeTuioListener(this);
        client.disconnect();
        Environment.Exit(0);
    }

    public void addTuioObject(TuioObject o)
    {
        TuioDemoObject demoObj = new TuioDemoObject(o);

        if (!isLoggedIn)
        {
            if (o.SymbolID == LOGIN_MARKER_ID)
            {
                isLoggedIn = true;

                lock (objectSync)
                {
                    objectList.Clear();
                }

                lock (scannedSync)
                {
                    scannedMarkers.Clear();
                    scanHistory.Clear();
                }

                Console.WriteLine("[LOGIN SUCCESS] Marker 25 detected. Opening main page...");
                Invalidate();
            }
            else
            {
                Console.WriteLine("[LOGIN BLOCKED] Waiting for Marker 25. Detected Marker: " + o.SymbolID);
            }

            return;
        }

        lock (objectSync)
        {
            objectList[o.SessionID] = demoObj;
        }

        lock (scannedSync)
        {
            scannedMarkers[o.SymbolID] = demoObj;

            if (scanHistory.Contains(o.SymbolID))
                scanHistory.Remove(o.SymbolID);

            scanHistory.Add(o.SymbolID);
        }

        Console.WriteLine("[SCAN] Marker " + o.SymbolID + " saved.");
    }

    public void updateTuioObject(TuioObject o)
    {
        if (!isLoggedIn)
        {
            if (o.SymbolID == LOGIN_MARKER_ID)
            {
                isLoggedIn = true;

                lock (objectSync)
                {
                    objectList.Clear();
                }

                lock (scannedSync)
                {
                    scannedMarkers.Clear();
                    scanHistory.Clear();
                }

                Console.WriteLine("[LOGIN SUCCESS] Marker 25 detected during update. Opening main page...");
                Invalidate();
            }

            return;
        }

        TuioDemoObject demoObj = new TuioDemoObject(o);

        lock (objectSync)
        {
            objectList[o.SessionID] = demoObj;
        }

        lock (scannedSync)
        {
            scannedMarkers[o.SymbolID] = demoObj;
        }
    }

    public void removeTuioObject(TuioObject o)
    {
        if (!isLoggedIn)
            return;

        lock (objectSync)
        {
            if (objectList.ContainsKey(o.SessionID))
                objectList.Remove(o.SessionID);
        }

        Console.WriteLine("[LIVE REMOVED] Marker " + o.SymbolID + " removed from camera view but kept in scanned list.");
    }

    public void addTuioCursor(TuioCursor c) { }
    public void updateTuioCursor(TuioCursor c) { }
    public void removeTuioCursor(TuioCursor c) { }
    public void addTuioBlob(TuioBlob b) { }
    public void updateTuioBlob(TuioBlob b) { }
    public void removeTuioBlob(TuioBlob b) { }

    public void refresh(TuioTime t)
    {
        Invalidate();
    }

    protected override void OnPaintBackground(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

        g.Clear(BG);

        if (!isLoggedIn)
        {
            DrawLoginScreen(g);
            return;
        }

        Dictionary<int, TuioDemoObject> detected;
        lock (scannedSync)
        {
            detected = new Dictionary<int, TuioDemoObject>(scannedMarkers);
        }

        DrawHeader(g);
        DrawIngredientGrid(g, detected);
        DrawCenterPanel(g, detected);
        DrawRightPanel(g, detected);
    }

    private void DrawLoginScreen(Graphics g)
    {
        Rectangle hero = new Rectangle(70, 70, WIN_W - 140, WIN_H - 140);
        Rectangle leftPanel = new Rectangle(hero.X + 24, hero.Y + 24, 430, hero.Height - 48);
        Rectangle rightPanel = new Rectangle(leftPanel.Right + 24, hero.Y + 24, hero.Width - leftPanel.Width - 72, hero.Height - 48);

        using (LinearGradientBrush bgBrush = new LinearGradientBrush(
            new Rectangle(0, 0, WIN_W, WIN_H),
            Color.FromArgb(255, 250, 244),
            Color.FromArgb(245, 239, 229),
            90f))
        {
            g.FillRectangle(bgBrush, 0, 0, WIN_W, WIN_H);
        }

        using (SolidBrush bubble1 = new SolidBrush(Color.FromArgb(70, 255, 140, 60)))
        using (SolidBrush bubble2 = new SolidBrush(Color.FromArgb(60, 46, 196, 182)))
        using (SolidBrush bubble3 = new SolidBrush(Color.FromArgb(45, 255, 211, 63)))
        {
            g.FillEllipse(bubble1, new Rectangle(40, 30, 180, 180));
            g.FillEllipse(bubble2, new Rectangle(WIN_W - 220, 60, 160, 160));
            g.FillEllipse(bubble3, new Rectangle(WIN_W - 260, WIN_H - 220, 220, 220));
        }

        FillRoundRect(g, Color.FromArgb(248, 253, 250), hero, 32);
        DrawRoundRect(g, Color.FromArgb(45, 0, 0, 0), hero, 32);

        FillRoundRect(g, Color.FromArgb(255, 245, 235), leftPanel, 28);
        DrawRoundRect(g, Color.FromArgb(25, 0, 0, 0), leftPanel, 28);

        FillRoundRect(g, CARD_BG, rightPanel, 28);
        DrawRoundRect(g, Color.FromArgb(25, 0, 0, 0), rightPanel, 28);

        DrawEmoji(g, "👨‍🍳", new Rectangle(leftPanel.X + 24, leftPanel.Y + 22, 44, 44));
        g.DrawString("Smart Kitchen Access", fontTitle, new SolidBrush(TEXT_PRI), new PointF(leftPanel.X + 72, leftPanel.Y + 24));
        g.DrawString("Cooking station login", fontSmall, new SolidBrush(CORAL), new PointF(leftPanel.X + 74, leftPanel.Y + 52));

        g.DrawString("Start Cooking with Your Marker", new Font("Segoe UI", 24, FontStyle.Bold), new SolidBrush(TEAL_DARK), new RectangleF(leftPanel.X + 24, leftPanel.Y + 92, leftPanel.Width - 48, 90));
        g.DrawString("This screen is now themed like a smart cooking station. Present the kitchen access marker and the main recipe dashboard will open automatically.", fontBody, new SolidBrush(TEXT_SEC), new RectangleF(leftPanel.X + 24, leftPanel.Y + 188, leftPanel.Width - 48, 74));

        Rectangle feature1 = new Rectangle(leftPanel.X + 24, leftPanel.Y + 292, leftPanel.Width - 48, 62);
        Rectangle feature2 = new Rectangle(leftPanel.X + 24, leftPanel.Y + 366, leftPanel.Width - 48, 62);
        Rectangle feature3 = new Rectangle(leftPanel.X + 24, leftPanel.Y + 440, leftPanel.Width - 48, 62);

        FillRoundRect(g, GREEN_LIGHT, feature1, 18);
        FillRoundRect(g, AMBER_LIGHT, feature2, 18);
        FillRoundRect(g, BLUE_LIGHT, feature3, 18);

        DrawEmoji(g, "🥘", new Rectangle(feature1.X + 14, feature1.Y + 15, 28, 28));
        g.DrawString("Ingredient tracking", fontH3, new SolidBrush(TEXT_PRI), new PointF(feature1.X + 48, feature1.Y + 11));
        g.DrawString("Scan ingredients and tools to build meals live.", fontSmall, new SolidBrush(TEXT_SEC), new PointF(feature1.X + 48, feature1.Y + 33));

        DrawEmoji(g, "🔥", new Rectangle(feature2.X + 14, feature2.Y + 15, 28, 28));
        g.DrawString("Recipe flow", fontH3, new SolidBrush(TEXT_PRI), new PointF(feature2.X + 48, feature2.Y + 11));
        g.DrawString("Get cooking steps, health score, and calories.", fontSmall, new SolidBrush(TEXT_SEC), new PointF(feature2.X + 48, feature2.Y + 33));

        DrawEmoji(g, "📷", new Rectangle(feature3.X + 14, feature3.Y + 15, 28, 28));
        g.DrawString("Hands-free entry", fontH3, new SolidBrush(TEXT_PRI), new PointF(feature3.X + 48, feature3.Y + 11));
        g.DrawString("No username or password, just scan the marker.", fontSmall, new SolidBrush(TEXT_SEC), new PointF(feature3.X + 48, feature3.Y + 33));

        DrawEmoji(g, "🍲", new Rectangle(rightPanel.X + 28, rightPanel.Y + 24, 36, 36));
        g.DrawString("Kitchen Login", new Font("Segoe UI", 20, FontStyle.Bold), new SolidBrush(TEXT_PRI), new PointF(rightPanel.X + 72, rightPanel.Y + 24));
        g.DrawString("Use the cooking access marker to continue", fontBody, new SolidBrush(TEXT_SEC), new PointF(rightPanel.X + 30, rightPanel.Y + 70));

        Rectangle idCard = new Rectangle(rightPanel.X + 34, rightPanel.Y + 116, rightPanel.Width - 68, 132);
        using (LinearGradientBrush idBrush = new LinearGradientBrush(idCard, Color.FromArgb(255, 129, 72), Color.FromArgb(242, 87, 51), 0f))
        {
            FillRoundRect(g, Color.Transparent, idCard, 24);
            using (GraphicsPath path = RoundedRect(idCard, 24))
            {
                g.FillPath(idBrush, path);
            }
        }

        g.DrawString("ACCESS MARKER", new Font("Segoe UI", 10, FontStyle.Bold), new SolidBrush(Color.FromArgb(255, 245, 235)), new PointF(idCard.X + 28, idCard.Y + 22));
        g.DrawString("", new Font("Segoe UI", 42, FontStyle.Bold), Brushes.White, new PointF(idCard.X + 28, idCard.Y + 42));
        g.DrawString("Scan this marker to unlock the cooking dashboard", fontSmall, new SolidBrush(Color.FromArgb(255, 239, 228)), new RectangleF(idCard.X + 150, idCard.Y + 52, idCard.Width - 170, 46));

        Rectangle stepBox = new Rectangle(rightPanel.X + 34, rightPanel.Y + 272, rightPanel.Width - 68, 164);
        FillRoundRect(g, GRAY_LIGHT, stepBox, 22);
        g.DrawString("How to enter", fontH2, new SolidBrush(TEXT_PRI), new PointF(stepBox.X + 22, stepBox.Y + 18));
        g.DrawString("1. Open reacTIVision in the background.", fontBody, new SolidBrush(TEXT_SEC), new PointF(stepBox.X + 22, stepBox.Y + 56));
        g.DrawString("2. Show marker  to the camera.", fontBody, new SolidBrush(TEXT_SEC), new PointF(stepBox.X + 22, stepBox.Y + 84));
        g.DrawString("3. The main kitchen page opens automatically.", fontBody, new SolidBrush(TEXT_SEC), new PointF(stepBox.X + 22, stepBox.Y + 112));

        Rectangle footer = new Rectangle(rightPanel.X + 34, rightPanel.Bottom - 96, rightPanel.Width - 68, 58);
        FillRoundRect(g, GREEN_LIGHT, footer, 18);
        DrawEmoji(g, "✅", new Rectangle(footer.X + 14, footer.Y + 15, 24, 24));
        g.DrawString("Ready to cook", fontH3, new SolidBrush(GREEN), new PointF(footer.X + 44, footer.Y + 10));
        g.DrawString("Only marker have access is allowed on this page.", fontSmall, new SolidBrush(TEAL_DARK), new PointF(footer.X + 44, footer.Y + 31));
    }

    private void DrawEmoji(Graphics g, string emoji, Rectangle rect)
    {
        TextRenderer.DrawText(
            g,
            emoji,
            fontEmoji,
            rect,
            Color.Black,
            TextFormatFlags.Left |
            TextFormatFlags.Top |
            TextFormatFlags.NoPadding |
            TextFormatFlags.NoPrefix
        );
    }

    private void DrawHeader(Graphics g)
    {
        Rectangle r = new Rectangle(PAD, PAD, WIN_W - PAD * 2, 66);
        FillRoundRect(g, CARD_BG, r, CARD_R);
        DrawRoundRect(g, Color.FromArgb(30, 0, 0, 0), r, CARD_R);

        DrawEmoji(g, "🍽", new Rectangle(r.X + 12, r.Y + 10, 28, 28));
        g.DrawString("Smart Kitchen", fontTitle, new SolidBrush(TEXT_PRI), new PointF(r.X + 46, r.Y + 8));
        g.DrawString(
            "Physical Objects Enabled: Spoon, Pot, Knife  •  Scan once to save  •  C=Clear  R=Remove Last  H=Tips  M=Steps  ESC=Exit",
            fontSmall, new SolidBrush(TEXT_SEC), new PointF(r.X + 16, r.Y + 40)
        );
    }

    private void DrawIngredientGrid(Graphics g, Dictionary<int, TuioDemoObject> detected)
    {
        int startY = PAD + 66 + 12;
        int panelW = 330;
        int cellW = (panelW - PAD * 2 - 8) / 2;
        int cellH = 88;

        g.DrawString("Scanned Items", fontH2, new SolidBrush(TEXT_PRI), new PointF(PAD, startY));
        startY += 26;

        for (int i = 0; i < items.Length; i++)
        {
            KitchenItem item = items[i];
            int col = i % 2;
            int row = i / 2;
            int x = PAD + col * (cellW + 8);
            int y = startY + row * (cellH + 8);

            bool isActive = detected.ContainsKey(item.MarkerID);
            DrawItemCard(g, item, new Rectangle(x, y, cellW, cellH), isActive, isActive ? detected[item.MarkerID] : null);
        }

        int legendY = startY + 5 * (cellH + 8) + 8;
        DrawRotationLegend(g, new Rectangle(PAD, legendY, panelW - PAD, 80));

        legendY += 92;
        DrawPhysicalObjectPanel(g, detected, new Rectangle(PAD, legendY, panelW - PAD, 110));
    }

    private void DrawItemCard(Graphics g, KitchenItem item, Rectangle r, bool active, TuioDemoObject obj)
    {
        Color bg = active ? item.LightColor : CARD_BG;
        Color bord = active ? item.AccentColor : Color.FromArgb(30, 0, 0, 0);
        int bw = active ? 2 : 1;

        FillRoundRect(g, bg, r, 10);
        using (Pen pen = new Pen(bord, bw))
        {
            DrawRoundRectPen(g, pen, r, 10);
        }

        Rectangle badge = new Rectangle(r.Right - 30, r.Y + 5, 26, 16);
        FillRoundRect(g, active ? item.AccentColor : GRAY_LIGHT, badge, 8);
        g.DrawString("M" + item.MarkerID, fontMarker,
                     new SolidBrush(active ? Color.White : GRAY_MID),
                     new PointF(badge.X + 3, badge.Y + 1));

        DrawEmoji(g, item.Emoji, new Rectangle(r.X + 6, r.Y + 2, 26, 26));
        g.DrawString(item.Name, fontH3, new SolidBrush(TEXT_PRI), new PointF(r.X + 6, r.Y + 32));

        if (item.IsTool)
        {
            g.DrawString(active ? "Physical Object Ready" : "Tool not scanned",
                         fontSmall,
                         new SolidBrush(active ? item.AccentColor : TEXT_SEC),
                         new PointF(r.X + 6, r.Y + 58));
        }
        else if (active && obj != null)
        {
            int grams = item.GetGrams(obj.Angle);
            int kcal = item.GetCalories(obj.Angle);
            g.DrawString(grams + "g  •  " + kcal + " kcal",
                         fontSmall,
                         new SolidBrush(item.AccentColor),
                         new PointF(r.X + 6, r.Y + 58));

            float deg = obj.Angle * 180f / (float)Math.PI;
            if (deg < 0) deg += 360f;
            DrawRotArc(g, new Point(r.Right - 18, r.Bottom - 18), 12, deg, item.AccentColor);
        }
        else
        {
            g.DrawString(item.KcalPerGram.ToString("F1") + " kcal/g",
                         fontSmall,
                         new SolidBrush(TEXT_SEC),
                         new PointF(r.X + 6, r.Y + 58));
        }
    }

    private void DrawRotationLegend(Graphics g, Rectangle r)
    {
        FillRoundRect(g, AMBER_LIGHT, r, CARD_R);
        g.DrawString("Rotation → Quantity", fontH3, new SolidBrush(AMBER), new PointF(r.X + 10, r.Y + 8));

        string[] labels = new string[]
        {
            "0°–89° = Small",
            "90°–179° = Medium",
            "180°–269° = Large",
            "270°–359° = X-Large"
        };

        for (int i = 0; i < labels.Length; i++)
        {
            int col = i % 2;
            int row = i / 2;
            g.DrawString(labels[i], fontSmall, new SolidBrush(TEXT_PRI),
                         new PointF(r.X + 10 + col * 120, r.Y + 30 + row * 18));
        }
    }

    private void DrawPhysicalObjectPanel(Graphics g, Dictionary<int, TuioDemoObject> detected, Rectangle r)
    {
        FillRoundRect(g, BLUE_LIGHT, r, CARD_R);

        bool spoon = detected.ContainsKey(6);
        bool pot = detected.ContainsKey(7);
        bool knife = detected.ContainsKey(8);

        g.DrawString("Physical Objects", fontH3, new SolidBrush(BLUE), new PointF(r.X + 10, r.Y + 8));
        g.DrawString("🥄 Spoon: " + (spoon ? "Scanned" : "Missing"), fontBody, new SolidBrush(TEXT_PRI), new PointF(r.X + 10, r.Y + 34));
        g.DrawString("🍲 Pot: " + (pot ? "Scanned" : "Missing"), fontBody, new SolidBrush(TEXT_PRI), new PointF(r.X + 10, r.Y + 56));
        g.DrawString("🔪 Knife: " + (knife ? "Scanned" : "Missing"), fontBody, new SolidBrush(TEXT_PRI), new PointF(r.X + 10, r.Y + 78));
    }

    private void DrawCenterPanel(Graphics g, Dictionary<int, TuioDemoObject> detected)
    {
        int x = 350;
        int y = PAD + 66 + 12;
        int w = 350;

        Rectangle top = new Rectangle(x, y, w, 90);
        DrawHealthScoreCard(g, detected, top);

        Rectangle middle = new Rectangle(x, y + 100, w, 120);
        DrawLastScannedCard(g, detected, middle);

        Rectangle bottom = new Rectangle(x, y + 230, w, 220);
        if (showMealSteps)
            DrawMealStepsCard(g, detected, bottom);
        else
            DrawToggleInfoCard(g, bottom, "Meal steps are hidden. Press M to show them.");
    }

    private void DrawHealthScoreCard(Graphics g, Dictionary<int, TuioDemoObject> detected, Rectangle r)
    {
        int totalCalories = GetTotalCalories(detected);
        int score = CalculateHealthScore(detected);

        FillRoundRect(g, GREEN_LIGHT, r, CARD_R);
        g.DrawString("Health Score", fontH3, new SolidBrush(TEAL_DARK), new PointF(r.X + 12, r.Y + 8));
        g.DrawString(score.ToString() + "/100", fontBig, new SolidBrush(GREEN), new PointF(r.X + 12, r.Y + 28));
        g.DrawString("Total Calories: " + totalCalories + " kcal", fontBody, new SolidBrush(TEXT_SEC), new PointF(r.X + 160, r.Y + 40));

        string level = "Balanced";
        if (score >= 85) level = "Very Healthy";
        else if (score >= 65) level = "Healthy";
        else if (score >= 45) level = "Needs Improvement";
        else level = "High Calorie";

        g.DrawString("Status: " + level, fontBody, new SolidBrush(TEXT_PRI), new PointF(r.X + 160, r.Y + 62));
    }

    private void DrawLastScannedCard(Graphics g, Dictionary<int, TuioDemoObject> detected, Rectangle r)
    {
        FillRoundRect(g, PURPLE_LIGHT, r, CARD_R);
        g.DrawString("Last Scanned Item", fontH3, new SolidBrush(PURPLE), new PointF(r.X + 12, r.Y + 8));

        if (scanHistory.Count == 0)
        {
            g.DrawString("No item scanned yet.", fontBody, new SolidBrush(TEXT_SEC), new PointF(r.X + 12, r.Y + 44));
            return;
        }

        int lastId = scanHistory[scanHistory.Count - 1];
        KitchenItem item = items.FirstOrDefault(i => i.MarkerID == lastId);
        TuioDemoObject obj = null;

        if (detected.ContainsKey(lastId))
            obj = detected[lastId];

        if (item == null)
        {
            g.DrawString("Unknown item", fontBody, new SolidBrush(TEXT_SEC), new PointF(r.X + 12, r.Y + 44));
            return;
        }

        DrawEmoji(g, item.Emoji, new Rectangle(r.X + 12, r.Y + 34, 28, 28));
        g.DrawString(item.Name, fontH2, new SolidBrush(TEXT_PRI), new PointF(r.X + 44, r.Y + 36));

        if (item.IsTool)
        {
            g.DrawString("This is a physical kitchen object.", fontBody, new SolidBrush(TEXT_SEC), new PointF(r.X + 12, r.Y + 72));
        }
        else if (obj != null)
        {
            g.DrawString("Quantity: " + item.GetQtyLabel(obj.Angle), fontBody, new SolidBrush(TEXT_SEC), new PointF(r.X + 12, r.Y + 72));
            g.DrawString("Calories: " + item.GetCalories(obj.Angle) + " kcal", fontBody, new SolidBrush(item.AccentColor), new PointF(r.X + 12, r.Y + 94));
        }
    }

    private void DrawMealStepsCard(Graphics g, Dictionary<int, TuioDemoObject> detected, Rectangle r)
    {
        FillRoundRect(g, CARD_BG, r, CARD_R);
        DrawRoundRect(g, Color.FromArgb(30, 0, 0, 0), r, CARD_R);

        g.DrawString("Cooking Steps", fontH3, new SolidBrush(TEXT_PRI), new PointF(r.X + 12, r.Y + 8));

        HashSet<int> activeMarkers = new HashSet<int>(detected.Keys);
        Recipe readyRecipe = null;

        foreach (Recipe recipe in recipes)
        {
            bool allPresent = true;
            foreach (int id in recipe.RequiredMarkers)
            {
                if (!activeMarkers.Contains(id))
                {
                    allPresent = false;
                    break;
                }
            }

            if (allPresent)
            {
                readyRecipe = recipe;
                break;
            }
        }

        if (readyRecipe == null)
        {
            g.DrawString("No complete recipe yet.", fontBody, new SolidBrush(TEXT_SEC), new PointF(r.X + 12, r.Y + 40));
            g.DrawString("Scan more ingredients and physical tools.", fontBody, new SolidBrush(TEXT_SEC), new PointF(r.X + 12, r.Y + 62));
            return;
        }

        DrawEmoji(g, readyRecipe.Emoji, new Rectangle(r.X + 12, r.Y + 32, 28, 28));
        g.DrawString(readyRecipe.Name, fontBody, new SolidBrush(TEXT_PRI), new PointF(r.X + 44, r.Y + 36));
        g.DrawString("Category: " + readyRecipe.Category, fontBody, new SolidBrush(TEXT_SEC), new PointF(r.X + 12, r.Y + 62));

        int stepY = r.Y + 88;
        for (int i = 0; i < readyRecipe.Steps.Length; i++)
        {
            if (stepY > r.Bottom - 20) break;
            g.DrawString((i + 1).ToString() + ". " + readyRecipe.Steps[i], fontSmall, new SolidBrush(TEXT_PRI), new PointF(r.X + 12, stepY));
            stepY += 24;
        }
    }

    private void DrawToggleInfoCard(Graphics g, Rectangle r, string text)
    {
        FillRoundRect(g, GRAY_LIGHT, r, CARD_R);
        g.DrawString(text, fontBody, new SolidBrush(TEXT_SEC), new PointF(r.X + 12, r.Y + 20));
    }

    private void DrawRightPanel(Graphics g, Dictionary<int, TuioDemoObject> detected)
    {
        int x = 720;
        int startY = PAD + 66 + 12;
        int w = WIN_W - x - PAD;

        int totalCal = GetTotalCalories(detected);
        DrawTotalCalCard(g, new Rectangle(x, startY, w, 64), totalCal, detected.Count);
        startY += 72;

        g.DrawString("Meal Suggestions", fontH2, new SolidBrush(TEXT_PRI), new PointF(x, startY));
        startY += 26;

        HashSet<int> activeMarkers = new HashSet<int>(detected.Keys);
        int drawn = 0;

        foreach (Recipe recipe in recipes)
        {
            List<int> have = recipe.RequiredMarkers.Where(m => activeMarkers.Contains(m)).ToList();
            List<int> missing = recipe.RequiredMarkers.Where(m => !activeMarkers.Contains(m)).ToList();

            if (have.Count == 0) continue;

            int cardH = missing.Count > 0 ? 110 : 96;
            DrawRecipeCard(g, recipe, new Rectangle(x, startY, w, cardH), have, missing);
            startY += cardH + 8;
            drawn++;
        }

        if (drawn == 0)
        {
            Rectangle er = new Rectangle(x, startY, w, 60);
            FillRoundRect(g, GRAY_LIGHT, er, CARD_R);
            g.DrawString("Scan ingredients and physical objects to see meal suggestions.",
                         fontBody, new SolidBrush(TEXT_SEC), new PointF(er.X + 12, er.Y + 20));
            startY += 68;
        }

        if (showHealthTips)
        {
            startY += 8;
            DrawTipsPanel(g, detected, new Rectangle(x, startY, w, WIN_H - startY - PAD));
        }
        else
        {
            startY += 8;
            Rectangle er = new Rectangle(x, startY, w, 50);
            FillRoundRect(g, GRAY_LIGHT, er, CARD_R);
            g.DrawString("Health tips are hidden. Press H to show them.",
                         fontBody, new SolidBrush(TEXT_SEC), new PointF(er.X + 12, er.Y + 16));
        }
    }

    private void DrawTipsPanel(Graphics g, Dictionary<int, TuioDemoObject> detected, Rectangle area)
    {
        g.DrawString("Diet Tips", fontH2, new SolidBrush(TEXT_PRI), new PointF(area.X, area.Y));
        int y = area.Y + 28;

        List<string> tips = new List<string>();
        foreach (int mid in detected.Keys)
        {
            KitchenItem item = items.FirstOrDefault(i => i.MarkerID == mid);
            if (item != null && item.Tips != null)
            {
                foreach (string tip in item.Tips)
                {
                    if (!tips.Contains(tip))
                        tips.Add(tip);

                    if (tips.Count >= 6)
                        break;
                }
            }

            if (tips.Count >= 6)
                break;
        }

        if (tips.Count == 0)
        {
            Rectangle tr = new Rectangle(area.X, y, area.Width, 30);
            FillRoundRect(g, AMBER_LIGHT, tr, 8);
            g.DrawString("Scan some items to get health advice.", fontSmall, new SolidBrush(TEXT_PRI), new PointF(tr.X + 10, tr.Y + 8));
            return;
        }

        foreach (string tip in tips)
        {
            if (y + 32 > area.Bottom) break;

            Rectangle tr = new Rectangle(area.X, y, area.Width, 34);
            FillRoundRect(g, AMBER_LIGHT, tr, 8);
            g.DrawString("💡 " + tip, fontSmall, new SolidBrush(TEXT_PRI), new PointF(tr.X + 10, tr.Y + 9));
            y += 40;
        }
    }

    private int GetTotalCalories(Dictionary<int, TuioDemoObject> detected)
    {
        int totalCal = 0;
        foreach (KeyValuePair<int, TuioDemoObject> kv in detected)
        {
            KitchenItem item = items.FirstOrDefault(i => i.MarkerID == kv.Key);
            if (item != null)
                totalCal += item.GetCalories(kv.Value.Angle);
        }
        return totalCal;
    }

    private int CalculateHealthScore(Dictionary<int, TuioDemoObject> detected)
    {
        int score = 50;

        bool hasChicken = detected.ContainsKey(0);
        bool hasTomato = detected.ContainsKey(1);
        bool hasOnion = detected.ContainsKey(2);
        bool hasSpices = detected.ContainsKey(3);
        bool hasRice = detected.ContainsKey(4);
        bool hasOil = detected.ContainsKey(5);

        if (hasChicken) score += 15;
        if (hasTomato) score += 10;
        if (hasOnion) score += 10;
        if (hasSpices) score += 5;
        if (hasRice) score += 5;

        if (hasOil)
        {
            KitchenItem oil = items.FirstOrDefault(i => i.MarkerID == 5);
            TuioDemoObject oilObj = detected[5];
            if (oil != null && oilObj != null)
            {
                int oilGrams = oil.GetGrams(oilObj.Angle);
                if (oilGrams <= 5) score += 5;
                else if (oilGrams <= 10) score -= 5;
                else score -= 15;
            }
        }

        int totalCalories = GetTotalCalories(detected);
        if (totalCalories > 800) score -= 15;
        else if (totalCalories > 500) score -= 5;

        if (score < 0) score = 0;
        if (score > 100) score = 100;
        return score;
    }

    private void DrawTotalCalCard(Graphics g, Rectangle r, int total, int count)
    {
        FillRoundRect(g, GREEN_LIGHT, r, CARD_R);
        g.DrawString(total.ToString(), fontBig, new SolidBrush(GREEN), new PointF(r.X + 14, r.Y + 8));
        g.DrawString("total kcal", fontSmall, new SolidBrush(TEAL_DARK), new PointF(r.X + 14, r.Y + 44));
        g.DrawString(count.ToString() + " scanned markers", fontSmall, new SolidBrush(TEXT_SEC), new PointF(r.X + r.Width / 2 - 30, r.Y + 26));
    }

    private void DrawRecipeCard(Graphics g, Recipe recipe, Rectangle r, List<int> have, List<int> missing)
    {
        bool canMake = missing.Count == 0;
        Color bg = canMake ? GREEN_LIGHT : CARD_BG;
        Color border = canMake ? GREEN : Color.FromArgb(30, 0, 0, 0);
        int bw = canMake ? 2 : 1;

        FillRoundRect(g, bg, r, CARD_R);
        using (Pen pen = new Pen(border, bw))
        {
            DrawRoundRectPen(g, pen, r, CARD_R);
        }

        DrawEmoji(g, recipe.Emoji, new Rectangle(r.X + 8, r.Y + 6, 26, 26));
        g.DrawString(recipe.Name, fontH3, new SolidBrush(TEXT_PRI), new PointF(r.X + 36, r.Y + 10));
        g.DrawString(recipe.Category, fontTiny, new SolidBrush(TEXT_SEC), new PointF(r.X + 36, r.Y + 32));

        string statusText = canMake ? "Ready to Cook" : "Missing " + missing.Count;
        Color statusBg = canMake ? GREEN : AMBER;
        Rectangle badgeRect = new Rectangle(r.Right - 110, r.Y + 8, 98, 20);
        FillRoundRect(g, statusBg, badgeRect, 10);
        g.DrawString(statusText, fontTiny, new SolidBrush(Color.White), new PointF(badgeRect.X + 8, badgeRect.Y + 4));

        int tx = r.X + 8;
        int ty = r.Y + 54;

        foreach (int mid in recipe.RequiredMarkers)
        {
            KitchenItem item = items.FirstOrDefault(i => i.MarkerID == mid);
            if (item == null) continue;

            bool h = have.Contains(mid);
            string tagText = item.Emoji + " " + item.Name;
            int tw = (int)g.MeasureString(tagText, fontTiny).Width + 12;
            Rectangle tagR = new Rectangle(tx, ty, tw, 18);

            FillRoundRect(g, h ? GREEN_LIGHT : CORAL_LIGHT, tagR, 9);
            g.DrawString(tagText, fontTiny,
                         new SolidBrush(h ? TEAL_DARK : CORAL),
                         new PointF(tx + 4, ty + 2));

            tx += tw + 4;
            if (tx > r.Right - 110)
            {
                tx = r.X + 8;
                ty += 22;
            }
        }

        if (!canMake)
        {
            string miss = "Missing: " + string.Join(", ",
                missing.Select(m =>
                {
                    KitchenItem item = items.FirstOrDefault(i => i.MarkerID == m);
                    return item != null ? item.Name : "?";
                }).ToArray());

            g.DrawString(miss, fontSmall, new SolidBrush(CORAL), new PointF(r.X + 8, r.Bottom - 22));
        }
    }

    private void FillRoundRect(Graphics g, Color color, Rectangle r, int radius)
    {
        using (GraphicsPath path = RoundedRect(r, radius))
        using (SolidBrush brush = new SolidBrush(color))
        {
            g.FillPath(brush, path);
        }
    }

    private void DrawRoundRect(Graphics g, Color color, Rectangle r, int radius)
    {
        using (GraphicsPath path = RoundedRect(r, radius))
        using (Pen pen = new Pen(color, 1))
        {
            g.DrawPath(pen, path);
        }
    }

    private void DrawRoundRectPen(Graphics g, Pen pen, Rectangle r, int radius)
    {
        using (GraphicsPath path = RoundedRect(r, radius))
        {
            g.DrawPath(pen, path);
        }
    }

    private GraphicsPath RoundedRect(Rectangle r, int radius)
    {
        int d = radius * 2;
        GraphicsPath path = new GraphicsPath();
        path.AddArc(r.X, r.Y, d, d, 180, 90);
        path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }

    private void DrawRotArc(Graphics g, Point center, int radius, float degrees, Color color)
    {
        using (Pen pen = new Pen(color, 2))
        using (Pen faintPen = new Pen(Color.FromArgb(40, color), 1))
        {
            g.DrawEllipse(faintPen, center.X - radius, center.Y - radius, radius * 2, radius * 2);

            float rad = degrees * (float)Math.PI / 180f;
            int ex = center.X + (int)(radius * Math.Cos(rad - Math.PI / 2));
            int ey = center.Y + (int)(radius * Math.Sin(rad - Math.PI / 2));
            g.DrawLine(pen, center.X, center.Y, ex, ey);
        }
    }

    [STAThread]
    public static void Main(string[] args)
    {
        int port = 3333;
        int p;
        if (args.Length == 1 && int.TryParse(args[0], out p) && p > 0)
            port = p;

        Console.WriteLine("Smart Kitchen starting on TUIO port " + port);
        Console.WriteLine("Login Marker: 25");
        Console.WriteLine("After login marker is scanned, main page will open.");
        Console.WriteLine("Marker mapping:");
        Console.WriteLine("  0=Chicken  1=Tomato  2=Onion  3=Spices  4=Rice  5=Oil");
        Console.WriteLine("  6=Spoon    7=Pot     8=Knife");
        Console.WriteLine("Controls: C=Clear, R=Remove Last, H=Tips, M=Steps, ESC=Exit");

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new SmartKitchenDemo(port));
    }
}